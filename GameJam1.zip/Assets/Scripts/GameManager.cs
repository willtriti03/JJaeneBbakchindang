﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour
{
	public int score = 0;


	void Start ()
	{
        UpSprite.NowScore = 0;
	}
	
	void Update ()
	{
	}
}
