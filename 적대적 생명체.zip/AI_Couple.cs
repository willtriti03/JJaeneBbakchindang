﻿using UnityEngine;
using System.Collections;

public class AI_Couple : HostileParent {
	public GameObject m_particle;
	public GameObject child_male;
	public NavMeshAgent child_nav;

	void Start () {
	    Nav = GetComponent<NavMeshAgent>(); //네비게이션 컴포넌트 접근/연결
		child_nav = child_male.GetComponent<NavMeshAgent>(); //자식 네비게이션 컴포넌트 접근/연결
		Nav.speed = m_Speed; //스피드 값 설정
	}

	void Update()
	{
		//시간차 합산
		m_DeltaTime += Time.deltaTime;

		if (!attackMode)
		{
			//랜덤이동 AI
			if (m_DeltaTime >= randomMoveDelay && Nav.enabled)
			{
				randomMove(Nav, Distance);
				m_DeltaTime -= randomMoveDelay;
			}
			//이벤트 발생, 공격 전환
			if (Input.GetKey(KeyCode.R))
			{
				m_DeltaTime = 0.0f;
				attackMode = true;
				Nav.enabled = false;
				child_nav.enabled = true;
				StartingPoint = child_male.transform.position;
			}
		}
		//남자친구 방향설정
		if (attackMode)
		{
			//플레이어 포기
			if (m_DeltaTime >= followTime)
			{
				attackMode = false;
				child_nav.SetDestination(StartingPoint);
			}
			//플레이어 목표
			else
				child_nav.SetDestination(Target_Player.position);

		}
		//원점으로 돌아왔을경우 오브젝트 제거
		if (child_male.transform.position == StartingPoint && !attackMode)
			Destroy(this.gameObject);
	}
	
	void OnDestroy()
	{
		//죽음 파티클
		Instantiate(m_particle, transform.position, transform.rotation);
	}
}
